package edu.gcu.jeffrey.mtgapichallenge;

import java.util.Arrays;

public class CardInformation {
    private String name, manaCost, type, text, power, toughness;//, imageUrl;

    private int cmc;

//    private  String[] supertypes, types, subtypes, printings;

//    private Rulings[] rulings;

//    private Legality[] legalities;

    public CardInformation(String name, String manaCost, String type, String rarity, String set, String setName, String text, String artist, String number, String power, String toughness, String layout, String multiverseid, String imageUrl, String originalText, String originalType, String id, int cmc, String[] supertypes, String[] types, String[] subtypes, String[] printings, Rulings[] rulings, Legality[] legalities) {
        this.name = name;
        this.manaCost = manaCost;
        this.type = type;
        this.text = text;
        this.power = power;
        this.toughness = toughness;
        this.cmc = cmc;
    }

    public CardInformation() {
    }

    @Override
    public String toString() {
        return "CardInformation{" +
                "name='" + name + '\'' + "\n" +
                "manaCost='" + manaCost + '\'' + "\n" +
                "cmc=" + cmc + "\n" +
                "type='" + type + '\'' + "\n" +
                "text='" + text + '\'' + "\n" +
                "power='" + power + '\'' +
                ", toughness='" + toughness + '\'' +
//                ", imageUrl='" + imageUrl + '\'' + "\n" +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManaCost() {
        return manaCost;
    }

    public void setManaCost(String manaCost) {
        this.manaCost = manaCost;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getToughness() {
        return toughness;
    }

    public void setToughness(String toughness) {
        this.toughness = toughness;
    }

    public int getCmc() {
        return cmc;
    }

    public void setCmc(int cmc) {
        this.cmc = cmc;
    }
}