package edu.gcu.jeffrey.mtgapichallenge;

public class Legality {
    public String format, legality;
}
