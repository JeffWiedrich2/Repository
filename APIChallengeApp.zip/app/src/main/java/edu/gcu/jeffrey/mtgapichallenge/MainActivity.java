package edu.gcu.jeffrey.mtgapichallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import io.magicthegathering.javasdk.api.CardAPI;
import io.magicthegathering.javasdk.api.MTGAPI;
import io.magicthegathering.javasdk.resource.Card;
import io.magicthegathering.javasdk.resource.MtgSet;

public class MainActivity extends AppCompatActivity {
    EditText et_name, et_convertedManaCost, et_colors, et_superType, et_type, et_subType,
            et_text, et_format;

    Button btn_search, btn_clearSearch;
    List<Card> cards;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_name = findViewById(R.id.et_name);
        et_convertedManaCost = findViewById(R.id.et_convertedManaCost);
        et_colors = findViewById(R.id.et_colors);
        et_superType = findViewById(R.id.et_superType);
        et_type = findViewById(R.id.et_type);
        et_subType = findViewById(R.id.et_subType);
        et_text = findViewById(R.id.et_text);
        et_format = findViewById(R.id.et_format);
        btn_search = findViewById(R.id.btn_search);
        btn_clearSearch = findViewById(R.id.btn_clearFields);

        cards = new ArrayList<>();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        btn_clearSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_name.setText("");
                et_convertedManaCost.setText("");
                et_colors.setText("");
                et_superType.setText("");
                et_type.setText("");
                et_subType.setText("");
                et_text.setText("");
                et_format.setText("");

                cards = new ArrayList<>();
            }
        });

        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search based on the info entered in the Edit Text fields

                cards = new ArrayList<>();
                List<CardInformation> cardInformationList = new ArrayList<>();

                // Do the search
                cards.add(CardAPI.getCard("1"));
                String url = "https://api.magicthegathering.io/v1/cards?";

                if (!et_name.getText().toString().equals("")){
                    url += "name=" + et_name.getText().toString();
                    if (!et_convertedManaCost.getText().toString().equals("") ||
                            !et_colors.getText().toString().equals("") ||
                            !et_superType.getText().toString().equals("") ||
                            !et_type.getText().toString().equals("") ||
                            !et_subType.getText().toString().equals("") ||
                            !et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_convertedManaCost.getText().toString().equals("")){
                    url += "cmc=" + et_convertedManaCost.getText().toString();
                    if (!et_colors.getText().toString().equals("") ||
                            !et_superType.getText().toString().equals("") ||
                            !et_type.getText().toString().equals("") ||
                            !et_subType.getText().toString().equals("") ||
                            !et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_colors.getText().toString().equals("")){
                    url += "color=" + et_colors.getText().toString();
                    if (!et_superType.getText().toString().equals("") ||
                            !et_type.getText().toString().equals("") ||
                            !et_subType.getText().toString().equals("") ||
                            !et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_superType.getText().toString().equals("")){
                    url += "supertype=" + et_superType.getText().toString();
                    if (!et_type.getText().toString().equals("") ||
                            !et_subType.getText().toString().equals("") ||
                            !et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_type.getText().toString().equals("")){
                    url += "type=" + et_type.getText().toString();
                    if (!et_subType.getText().toString().equals("") ||
                            !et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_subType.getText().toString().equals("")){
                    url += "subtypes=" + et_subType.getText().toString();
                    if (!et_text.getText().toString().equals("") ||
                            !et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_text.getText().toString().equals("")){
                    url += "text=" + et_text.getText().toString();
                    if (!et_format.getText().toString().equals("")) url += '&';
                }

                if (!et_format.getText().toString().equals("")){
                    url += "format=" + et_format.getText().toString();
                }

                JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url,
                        null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // It worked
                        try {
                            JSONArray consolidated_card_list = response.getJSONArray("cards");
                            for (int i = 0; i < consolidated_card_list.length(); i++){
                                CardInformation cardInformation = new CardInformation();

                                JSONObject card_selected = (JSONObject) consolidated_card_list.get(i);

                                cardInformation.setName(card_selected.getString("name"));
                                cardInformation.setManaCost(card_selected.getString("manaCost"));
                                cardInformation.setCmc(card_selected.getInt("cmc"));
                                cardInformation.setType(card_selected.getString("type"));
                                cardInformation.setPower(card_selected.getString("power"));
                                cardInformation.setToughness(card_selected.getString("toughness"));
                                cardInformation.setText(card_selected.getString("text"));
                                //cardInformation.setImageUrl(card_selected.getString("imageUrl"));


                                cardInformationList.add(cardInformation);
//                                Toast.makeText(MainActivity.this, cardInformationList.toString(), Toast.LENGTH_SHORT).show();

                                MySingleton.getInstance(MainActivity.this);
                                MySingleton.setCardInformationList(cardInformationList);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            //Toast.makeText(MainActivity.this, "You're not getting into the object", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // It didn't
                    }
                });

                // Add cards to Singleton
                MySingleton.getInstance(MainActivity.this).addToRequestQueue(request);


                Intent i = new Intent(MainActivity.this, SearchResultsScreen.class);
                startActivity(i);
            }
        });
    }
}