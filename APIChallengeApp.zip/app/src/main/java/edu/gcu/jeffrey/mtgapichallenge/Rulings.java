package edu.gcu.jeffrey.mtgapichallenge;

public class Rulings {
    public String date, text;
}
