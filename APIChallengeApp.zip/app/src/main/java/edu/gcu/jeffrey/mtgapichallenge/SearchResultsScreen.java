package edu.gcu.jeffrey.mtgapichallenge;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SearchResultsScreen extends AppCompatActivity {
    ListView lv_searchResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results_screen);

        lv_searchResults = findViewById(R.id.lv_searchResults);

        Runnable r = new Runnable() {
            @Override
            public void run() {
                ArrayAdapter arrayAdapter = new ArrayAdapter(SearchResultsScreen.this,
                        android.R.layout.simple_list_item_1, MySingleton.getCardInformationList());
                lv_searchResults.setAdapter(arrayAdapter);
            }
        };

        Handler h = new Handler();
        h.postDelayed(r, 5000);
    }
}