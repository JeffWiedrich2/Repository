#include <vector>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

vector<string> split(string s, string delimiter) 
{
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    string token;
    vector<std::string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != string::npos) {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}

void AbstractSyntaxTree()
{
    fstream newfile;
    newfile.open("outputFile.txt"); //Change the file name here to match your output.
    fstream outputFile;
    outputFile.open("outputFileB.txt");

    string inputData[88][3];
    int depthCounter = 0;
    int colnum = 0; // column number of the array
    int rownum = 0; // row number of the array

    if (newfile.is_open())
    {
        rownum = 0;
        string str;
        // read file
        while (getline(newfile, str))
        {
            // parse columns
            string delimiter = " | ";
            vector<string> v = split(str, delimiter);

            // populate astr array
            for (auto i : v)
            {
                inputData[rownum][colnum] = i;
                colnum++;
            }
            rownum++;
            colnum = 0;
        }
    }
    rownum = sizeof(inputData) / sizeof(inputData[0]);

    for (int i = 0; i <= rownum; i++)
    {
        if (inputData[i][1] != "operator")
        {
      		for (int j = 0; j < depthCounter; j++) 
        	{
          	outputFile << " ";
        	}
        }
      
      	if (inputData[i+1][1] == "operator")
        {
        	outputFile << inputData[i+1][0] + ": \n";
          depthCounter++;
          for (int j = 0; j < depthCounter; j++) 
          {
            outputFile << " ";
          }
        }
      	else if(inputData[i-1][1] == "operator") depthCounter--;

        if (inputData[i][1] != "bracket" && inputData[i][1] != "block" && inputData[i][1] != "break" && inputData[i][1] != "Type" && inputData[i][1] != "operator")
        {
            outputFile << inputData[i][0] + "\n";
        }

        if (inputData[i][0] == "(" || inputData[i][0] == "[" || inputData[i][0] == "{") depthCounter++;
        else if (inputData[i][0] == ")" || inputData[i][0] == "]" || inputData[i][0] == "}") depthCounter--;
    }
}

int main()
{
 AbstractSyntaxTree(); 
}