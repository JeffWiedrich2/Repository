----------------Instruction to Run the MIPS Code Generator--------------

Things given:
MIPS.cpp file 
Test file for Optimizer - OutputFile.txt



-> Create a project that contains the MIPS.cpp file
-> Add the OutputFile.txt to the project
-> If you wanted to use a different input file, you can go to line 28 and change it there.
-> Run the MIPS code generator (it will automatically read from the file since its hardcoded in)
-> It will generate an outputFileC.txt
