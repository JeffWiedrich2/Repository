----------------Instruction to Run the Optimizer--------------

Things given:
Optimzer.cpp file 
Test file for Optimizer - outputFile.txt



-> Create a project that contains the Optimizer.cpp file
-> Add the outputFile.txt to the project
-> If you wanted to use a different input file, you can go to line 29 and change it there.
-> Run the Optimizer (it will automatically read from the file since its hardcoded in)
-> It will generate an outputFileC.txt
