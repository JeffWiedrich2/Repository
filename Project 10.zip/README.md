To be able to run this project you will need to have a Linux system installed either on your machine or in a virtual box.
It needs to have a visual component as well so that the output is able to be displayed.
To be able to build and run the code you will need to have GL, GLUT, and GLU installed on your machine.
You can Install them using the following commands:
	sudo apt-get update
	sudo apt-get install libglu1-mesa-dev freeglut3-dev mesa-common-dev
Install the library stb_image.h. This can be done using the Ubuntu terminal, however this project uses the downloaded public domain file from github
The link is this: https://github.com/nothings/stb/blob/master/stb_image.h
Once you have those libraries installed you will need to build the code within the console.
To build the program you will need to be in the same directory as the source code is.
You will also need to have the lsystemFile.ls code within the same directory as the source code for the program to run.
To build the code you can use the command g++ project9.cpp -o project9 -lGL -lGLU -lglut
Then you can run the code by entering ./animation and hitting enter.
A window will then be created that contains the scene.

CONTROLS
Right Arrow	Slide camera 1 unit in the positive X direction
Left Arrow	Slide camera 1 unit in the negative X direction
Up Arrow	Slide camera 1 unit in the positive Y direction
Down Arrow	Slide camera 1 unit in the negative Y direction
Shift Up Arrow	Slide camera 1 unit in the positive Z ("in") direction
Shift Down Arrow	Slide camera 1 unit in the negative Z ("out") direction
Control Down Arrow	Change camera pitch by 2 degrees
Control Up Arrow	Change camera pitch by -2 degrees
Control Right Arrow	Change camera yaw by 2 degrees
Control Left Arrow	Change camera yaw by -2 degrees
<	Change camera roll by 2 degrees
>	Change camera roll by -2 degrees
r	Reset to the default position and orientation

To exit the scene the user can then enter the letter e to close the program.
Loom video: https://www.loom.com/share/91c9c6e7fe5a4f10bfa35e68ce7d401a