//Project 10 - Jeffrey Wiedrich
//Header files
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include <iostream>
#include <GL/glut.h> //glut library
#include <fstream>
#include <GLFW/glfw3.h>
#include <vector>

// Colors for checkerboard 
GLfloat WHITE[] = { 1, 1, 1 }; //White Color
GLfloat BLACK[] = { 0, 0, 0 }; //Black Color
GLfloat CHECKERBOARDCOLOR1[] = { 1,0,0 }; // A red color for the checkerboard
GLfloat CHECKERBOARDCOLOR2[] = { 0,0,1 }; // A blue color for the checkerboard


//Global Variables
double centerx = 0;     //center x value for the camera to look at
double centery = 0.0;   //center y value for the camera to look at
double centerz = 4;     //center z value for the camera to look at
double getX = 11;       //x value for the camera to look from
double getY = 2;        //y value for the camera to look from
double getZ = 4;        //z value for the camera to look from
double moveBy = 1;      //Value to move the camera by for basic camera movement
float rotate = 0;       //Roll variable that will be changed by player input 
float pitch = 0;        //Pitch variable that will be changed by player input
float yaw = 0;          //Yaw variable that will be changed by player input
GLuint cube_texture[6]; // Array to hold the textures for the cube map

//Checkerboard class that creates the checkerboard
class Checkerboard
{
    int displayListId;  // holds the value to display the checkerboard.
    int width;          //Sets the width of the checkerboard
    int depth;          //Sets the depth of the checkerboard

public:
    //Constructor that takes in the width and depth as parameter as sets it as the checkerboards width and depth.
    Checkerboard(int width, int depth) : width(width), depth(depth)
    {
    }

    //function to craete the checkerboard
    void create()
    {
        displayListId = glGenLists(1);                    //Holds the generated empty display list.
        glNewList(displayListId, GL_COMPILE);             //Creates and replaces the empty generated display list.
        GLfloat lightPosition[] = { 4, 3, 7, 1 };         //float Array to hold the position of the light.
        glLightfv(GL_LIGHT0, GL_POSITION, lightPosition); //Creates a Light source on the lightposition.
        glBegin(GL_QUADS);                                //Uses GL_QUADS to draw the checkerboard square pieces
        glNormal3d(0, 1, 0);                              //Sets the normal value so that the square pieces are facing up in Y direction.
        for (int x = 0; x < width - 1; x++)               //For loop to iterate through the given width which is 8 in our case.
        {
            for (int z = 0; z < depth - 1; z++)           //For loop to iterate through the given depth which is 8 in our case.
            {
                glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, (x + z) % 2 == 0 ? CHECKERBOARDCOLOR1 : CHECKERBOARDCOLOR2); //Sets the color of the square piece, by checking the previous piece...if the previous one was black then it gives the new piece color white.
                glVertex3f(x, 0, z);            //Bottom Left coordinate to draw the square
                glVertex3f(x + 1, 0, z);        //Bottom Right coordinate to draw the square
                glVertex3f(x + 1, 0, z + 1);    //Top Right coordinate to draw the square
                glVertex3f(x, 0, z + 1);        //Top Left coordinate to draw the square

                //Note: Since we are in the for loop, the x and z values will keep increasing thus populating the checkerboard.
            }
        }
        glEnd();        //glEnd() to let the program know to stop drawing the Quads
        glEndList();    //glEndList() to stop populating the list.
    }

    //Function to actually draw the checkerboard
    void draw()
    {
        glCallList(displayListId);      //glCallList is a in-built function in glut used to execute the display list
    }
};

// Initializing the checkerboard with 8 width and 8 depth, it will create a 8 x 8 checkerboard.
Checkerboard checkerboard(8, 8);


// Application-specific initialization: Set up global lighting parameters
// and create display lists.
void init()
{
    glEnable(GL_DEPTH_TEST);                      // Enables Server-side Depth Test Capability
    glLightfv(GL_LIGHT0, GL_DIFFUSE, WHITE);      //Creates a WHITE diffuse Light
    glLightfv(GL_LIGHT0, GL_SPECULAR, WHITE);     //Creates a WHITE Specular light
    glMaterialfv(GL_FRONT, GL_SPECULAR, WHITE);   //Gives information to material, where it should be absorbing the specular white light
    glMaterialf(GL_FRONT, GL_SHININESS, 30);      //Gives information to material, how much shininess that material should have.
       /*If enabled and no vertex shader is active, use the current lighting parameters to compute the
     * vertex color or index. Otherwise, simply associate the current color or index with each
     * vertex.*/

    glEnable(GL_TEXTURE_2D);
    glEnable(GL_TEXTURE_GEN_S);
    glEnable(GL_TEXTURE_GEN_T);
    glEnable(GL_LIGHTING);
    // Include light 0 in the evaluation of the lighting equation
    glEnable(GL_LIGHT0);
    // Have one or more material parameters track the current color.
    glEnable(GL_COLOR_MATERIAL);
    checkerboard.create();
    // Clear window color to a shade of white
    glClearColor(0.0, 0.0, 0.0, 0.0);
    // Make sures that the shading on the object is smooth rather than flat
    // To make the shading flat replace the GL_SMOOTH with GL_FLAT
    glShadeModel(GL_SMOOTH);
}


GLuint LoadTexture(const char* filename) // Function to load textures
{
    GLuint texture; // Creates a variable to hold the texture
    int width, height; // Holds the height and width of the image
    unsigned char* data; // Data variable to interact with the texture

    FILE* file; // FILE type to read from a file
    file = fopen(filename, "rb"); // Opening the file

    if (file == NULL) return 0; // Breaking out in case there's an error reading the file
    width = 1024; // Sets height
    height = 512; // Sets width
    data = (unsigned char*)malloc(width * height * 3); // Modifies the data varaible
    fread(data, width * height * 3, 1, file); // Reads values from the file
    fclose(file); // Closes the file

    for (int i = 0; i < width * height; ++i) // Starts off the for loop
    {
        int index = i * 3; // Sets the index variable
        unsigned char B, R; // Declares temporary variables
        B = data[index]; // Fills out temporary variable B
        R = data[index + 2]; // Fills out temporary variable R

        data[index] = R; // Integrates R into the data array
        data[index + 2] = B; // Integrates B into the data array
    }

    glGenTextures(1, &texture); // Begin setting up the textures in glut
    glBindTexture(GL_TEXTURE_2D, texture); // Starts the texture
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); // Puts the texture in env mode
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST); // Tells the texture to use the nearest mipmap

    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // Tells the texture to run linearly
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Tells the texture to repeat
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); // Tells the texture to repeat
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_RGB, GL_UNSIGNED_BYTE, data);
    free(data); // Frees up the data variable

    return texture; // Returns a texture
}

// Holds the texture image names
std::vector<std::string> face 
{
    "posy.jpg", // Positive y image name
    "negx.jpg", // Negative x image name
    "posx.jpg", // Positive x image name
    "negz.jpg", // Negative z image name
    "posz.jpg", // Positive z image name
    "negy.jpg" // Negative y image name
};

unsigned int loadCubemap(std::vector<std::string> faces, unsigned int i) // Loads the cubemap textures
{
    unsigned int textureID; // Holds the texture
    glGenTextures(1, &textureID); // Begins generating the texture
    glBindTexture(GL_TEXTURE_2D, textureID); // Sets up the command for calling upon the texture

    int widthCubemap, heightCubemap, nrChannelsCubemap; // Gets the variables nessecary to generate the texture ready
    unsigned char* dataCubemap = stbi_load(faces[i].c_str(), &widthCubemap, &heightCubemap, &nrChannelsCubemap, 0); // Starts up the data varaible
    if (dataCubemap) // Makes sure the texture is being read
    {
        // Grabs the texture from the file, and gets it ready for use
        glTexImage2D(GL_TEXTURE_2D, 
            0, GL_RGB, widthCubemap, heightCubemap, 0, GL_RGB, GL_UNSIGNED_BYTE, dataCubemap
        );
        stbi_image_free(dataCubemap); // Frees the imaging on the data variable
    }
    else
    {
        std::cout << "Cubemap tex failed to load at path: " << faces[i] << std::endl; // Tells the user the texture which isn't loading 
        stbi_image_free(dataCubemap); // Frees the imaging on the data variable
    }
    // Sets up the information on how the texture functions
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // Tells the texture to run linearly
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // Tells the texture to run linearly
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); // Tells the texture to repeat

    return textureID; // Returns the value nessecary to call the texture
}

// Draws one frame, the checkerboard then the Sphere, Cube, and Cylinder from the current camera position.
void display()
{


    unsigned int texture0; // Holds the texture
    glGenTextures(1, &texture0); // Begins generating the texture
    glBindTexture(GL_TEXTURE_2D, texture0); // Sets up the command for calling upon the texture
    // set the texture wrapping/filtering options (on the currently bound texture object)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // Tells the texture to repeat
    // load and generate the texture
    int width, height, nrChannels; // Gets the variables nessecary to generate the texture ready
    unsigned char* data = stbi_load("Bump-Map.jpg", &width, &height, &nrChannels, 0); // Starts up the data varaible
    if (data) // Makes sure the texture is being read
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data); // Gets the texture ready
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl; // Tells the user the texture which isn't loading 
    }
    stbi_image_free(data); // Frees the imaging on the data variable

    unsigned int texture1; // Holds the texture
    glGenTextures(1, &texture1); // Begins generating the texture
    glBindTexture(GL_TEXTURE_2D, texture1); // Sets up the command for calling upon the texture
    // set the texture wrapping/filtering options (on the currently bound texture object)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // Tells the texture to repeat
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR); // Tells the texture to repeat
    // load and generate the texture
    int width1, height1, nrChannels1; // Gets the variables nessecary to generate the texture ready
    unsigned char* data1 = stbi_load("Bump-Picture.jpg", &width1, &height1, &nrChannels1, 0); // Starts up the data varaible
    if (data1) // Makes sure the texture is being read
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width1, height1, 0, GL_RGB, GL_UNSIGNED_BYTE, data1); // Gets the texture ready
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl; // Tells the user the texture which isn't loading 
    }
    stbi_image_free(data1); // Frees the imaging on the data variable

    for (unsigned int j = 0; j < 6; j++) // Loops though the cube texture array
    {
        cube_texture[j] = loadCubemap(face, j); // Loads the cube texture array with the textures for each cube face
    }

    //GLuint texture1;
    //GLuint texture2;
    //texture1 = LoadTexture( "Bump-Map.jpg" );
    //texture2 = LoadTexture("Bump-Picture.jpg");

    // Clear the color buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Set up matrix by pushing identity matrix onto buffer
    glLoadIdentity();
    //glRotatef that handles the Pitch of the Camera
    glRotatef(pitch, 1.0, 0.0, 0.0);
    //glRotatef that handles the Yaw of the Camera
    glRotatef(yaw, 0.0, 1.0, 0.0);
    //glRotatef that handles the Roll of the Camera
    glRotatef(rotate, 0.0, 0.0, 1.0);

    // Set the camera to look at the centerx, centery, centerz from getX, getY, getZ to get the view of the checkerboard and the objects.
    gluLookAt(getX, getY, getZ, centerx, centery, centerz, 0, 1, 0);

    //Draw the checkerboard in the scene
    checkerboard.draw();

    /////////////SPHERE///////////
    // Float array to hold the sunlight position values which will be used in the glLightfv functon.
    GLfloat sunlight_position[] = { 0.0, 4.0, -5.0, 0.0 };
    // Sets the color of the light to White.
    glColor3f(1.0, 1.0, 1.0);
    // Sets the value of the GL_Light0's position and the light position.
    glLightfv(GL_LIGHT0, GL_POSITION, sunlight_position);
    //Translate the Sphere to the position given below
    glTranslatef(4.25, 0.5, 3.25);
    // Push a GL matrix for processing a more complex GL figure
    glPushMatrix();
    //Binds the texture to the following object
    glBindTexture(GL_TEXTURE_2D, texture0);
    //Set the Color of the Sphere to white
    glColor3f(1.0, 1.0, 1.0);
    // Creating a SolidSphere of radius 0.5 with 30 slices for the sphere Object.
    glutSolidSphere(.5, 30, 30);
    //Stops binding the texture
    glBindTexture(GL_TEXTURE_2D, 0);
    // Pop the matrix to finish drawing GLUT sphere
    glPopMatrix();

    ///////////CUBE///////////// 
    // Sets the value of the GL_Light0's position and the light position.
    glLightfv(GL_LIGHT0, GL_POSITION, sunlight_position);
    //Sets the position of the Cube to coordinates given below
    // Push a GL matrix for processing a more complex GL figure
    double length = 1;
    glPushMatrix(); //starts stack
    glTranslated(0.0, 0.0, 1.25); //trasnlate xyz position

    glBindTexture(GL_TEXTURE_2D, cube_texture[0]);//Sets the texture to cube texture[0]
   //Draws GL Quads for the top of the cube
    glBegin(GL_QUADS);
    // Texture Coordinates and drawing Coordinate
    glTexCoord2f(0, 1); glVertex3d(length / 2, length / 2, length / 2); //First Coord
    glTexCoord2f(1, 1); glVertex3d(-length / 2, length / 2, length / 2); //Second Coord
    glTexCoord2f(1, 0); glVertex3d(-length / 2, length / 2, -length / 2); //Third Coord
    glTexCoord2f(0, 0); glVertex3d(length / 2, length / 2, -length / 2); //Fourth Coord
    glEnd();

    glBindTexture(GL_TEXTURE_2D, cube_texture[1]);//Sets the texture to cube texture[1]
    //Draws GL Quads for the left of the cube
    glBegin(GL_QUADS);
    //Sets the Texture Coordinates and drawing coordinate
    glTexCoord2f(0, 1); glVertex3d(length / 2, length / 2, length / 2); //First Coord
    glTexCoord2f(1, 1); glVertex3d(length / 2, length / 2, -length / 2);//Second Coord
    glTexCoord2f(1, 0); glVertex3d(length / 2, -length / 2, -length / 2);//Third Coord
    glTexCoord2f(0, 0); glVertex3d(length / 2, -length / 2, length / 2); //Fourth Coord
    glEnd();

    glBindTexture(GL_TEXTURE_2D, cube_texture[2]);//Sets the texture to cube texture[2]
    //Draws GL Quads for the right of the cube
    glBegin(GL_QUADS);
    //Sets the Texture Coordinates and drawing coordinate
    glTexCoord2f(0, 1); glVertex3d(-length / 2, length / 2, length / 2);  //First Coord
    glTexCoord2f(1, 1); glVertex3d(-length / 2, length / 2, -length / 2); //Second Coord
    glTexCoord2f(1, 0); glVertex3d(-length / 2, -length / 2, -length / 2);//Third Coord
    glTexCoord2f(0, 0); glVertex3d(-length / 2, -length / 2, length / 2); //Fourth Coord
    glEnd();

    glBindTexture(GL_TEXTURE_2D, cube_texture[3]);//Sets the texture to cube texture[3]
    //Draws GL Quads for the back of the cube
    glBegin(GL_QUADS);
    //Sets the Texture Coordinates and drawing coordinate
    glTexCoord2f(0, 1); glVertex3d(length / 2, length / 2, length / 2); //First Coord
    glTexCoord2f(1, 1); glVertex3d(-length / 2, length / 2, length / 2); //Second Coord
    glTexCoord2f(1, 0); glVertex3d(-length / 2, -length / 2, length / 2);//Third Coord
    glTexCoord2f(0, 0); glVertex3d(length / 2, -length / 2, length / 2); //Fourth Coord
    glEnd();

    glBindTexture(GL_TEXTURE_2D, cube_texture[4]);//Sets the texture to cube texture[4]
    //Draws GL Quads for the front of the cube
    glBegin(GL_QUADS);
    //Sets the Texture Coordinates and drawing coordinate
    glTexCoord2f(1, 1); glVertex3d(length / 2, length / 2, -length / 2); //First Coord
    glTexCoord2f(0, 1); glVertex3d(-length / 2, length / 2, -length / 2);//Second Coord
    glTexCoord2f(0, 0); glVertex3d(-length / 2, -length / 2, -length / 2);//Third Coord
    glTexCoord2f(1, 0); glVertex3d(length / 2, -length / 2, -length / 2); //Fourth Coord
    glEnd();

    glBindTexture(GL_TEXTURE_2D, cube_texture[5]);//Sets the texture to cube texture[5]
    //Draws GL Quads for the bottom of the cube
    glBegin(GL_QUADS);
    //Sets the Texture Coordinates and drawing coordinate
    glTexCoord2f(1, 0); glVertex3d(length / 2, -length / 2, length / 2); //First Coord
    glTexCoord2f(0, 0); glVertex3d(-length / 2, -length / 2, length / 2);//Second Coord
    glTexCoord2f(0, 1); glVertex3d(-length / 2, -length / 2, -length / 2);//Third Coord
    glTexCoord2f(1, 1); glVertex3d(length / 2, -length / 2, -length / 2); //Fourth Coord
    glEnd();
    //Binds no texture to the drawing texture
    glBindTexture(GL_TEXTURE_2D, 0);
    //Pops off the matrix stack
    glPopMatrix();

    ///////////////CYLINDER////////////////
    //Sets the color of the Cylinder to Blue
    glColor3f(1.0, 1.0, 1.0);
    // Sets the value of the GL_Light0's position and the light position.
    glLightfv(GL_LIGHT0, GL_POSITION, sunlight_position);
    //Binds the texture to the following object
    glBindTexture(GL_TEXTURE_2D, texture1);
    // Sets the position of the cylinder
    glTranslatef(0.0, 0.5, -2.5);
    // Sets the rotation of the cylinder
    glRotatef(90, 1, 0, 0);
    // Begins by creating a polygon
    glBegin(GL_POLYGON);
    // Makes a quadric object 
    GLUquadricObj* obj = gluNewQuadric();
    // Creates the cylinder
    gluCylinder(obj, 0.5, 0.5, 1, 30, 30);
    // Stops binding the texture
    glBindTexture(GL_TEXTURE_2D, 0);
    glEnd();      //Stop drawing the Cylinder.

    //Performs a buffer swap on the layer in use for the current project.
    glutSwapBuffers();
    // End drawing of scene by flushing scene
    glFlush();
}

// On reshape, constructs a camera that perfectly fits the window.
void reshape(GLint w, GLint h)
{
    // Set up window viewport to the width and height for the window in the parameter
    glViewport(0, 0, w, h);
    // Set up the matrix mode to a sixteen-value spread, initially the identity matrix
    glMatrixMode(GL_PROJECTION);
    // Set up matrix by pushing identity matrix onto buffer
    glLoadIdentity();
    //gluPerspective specifies a viewing frustum into the world coordinate system
    gluPerspective(40.0, GLfloat(w) / GLfloat(h), 1.0, 150.0);
    //Applies subsequent matrix operations to the modelview matrix stack.
    glMatrixMode(GL_MODELVIEW);
}

// Requests to draw the next frame.
void timer(int v)
{
    //Calls for the program to redisplay the scene
    glutPostRedisplay();
    glutTimerFunc(1000 / 60, timer, v); //How frequent the timer function will call itself.
}


// Callback routine for ASCII characters
void processNormalKeys(unsigned char key, int x, int y)
{
    // If the user hits the "R" or "r" reset the values.
    if (key == 82 || key == 114) // Checking for the r/R key
    {
        centerx = 0;       //Reset the centerx to 0
        centery = 0.0;     //Reset the centery to 0
        centerz = 4;       //Reset the centerz to 4
        getX = 11;         //Reset the getX to 11
        getY = 2;          //Reset the getY to 2
        getZ = 4;          //Reset the getZ to 4
        pitch = 0;         //Reset Pitch to 0
        yaw = 0;           //Reset yaw to 0
        rotate = 0;        //Reset roll to 0
    }

    if (key == 62) // Check of the > key
    {
        rotate -= 2; //decreases the roll of the camera by 2 degrees
    }
    else if (key == 60) //checks for the < key
    {

        rotate += 2; //Increases the roll of the camera by 2 degrees
    }
}

//Funtion to handle user input.
void special(int key, int, int)
{

    int mod = glutGetModifiers(); // Get if any modifiers are active

    if (mod != GLUT_ACTIVE_SHIFT
        && mod != GLUT_ACTIVE_CTRL) // Making sure that alt and shift aren't pressed
    {
        if (key == GLUT_KEY_UP) // Checking the up arrow
        {
            getY += moveBy; // Move the camera up by "moveBy" on the y axis
            centery += moveBy; // Move the point it's looking at up by "moveBy" on the y axis
        }
        else if (key == GLUT_KEY_DOWN) // Checking the down arrow
        {
            getY -= moveBy; // Move the camera down by "moveBy" on the y axis
            centery -= moveBy; // Move the point it's looking at down by "moveBy" on the y axis
        }

        if (key == GLUT_KEY_RIGHT) // Checking the right arrow
        {
            getZ -= moveBy; // Move the camera up by "moveBy" on the x axis
            centerz -= moveBy; // Move the point it's looking at up by "moveBy" on the x axis
        }
        else if (key == GLUT_KEY_LEFT) // Checking the right arrow
        {
            getZ += moveBy; // Move the camera down by "moveBy" on the x axis
            centerz += moveBy; // Move the point it's looking at down by "moveBy" on the x axis
        }
    }
    else if (mod == GLUT_ACTIVE_SHIFT) // Check if shift is pressed
    {
        if (key == GLUT_KEY_UP) // Checking the up arrow
        {
            getX -= moveBy; // Move the camera up by "moveBy" on the z axis
            centerx -= moveBy; // Move the point it's looking at up by "moveBy" on the z axis
        }
        else if (key == GLUT_KEY_DOWN) // Checking the down arrow
        {
            getX += moveBy; // Move the camera down by "moveBy" on the z axis
            centerx += moveBy; // Move the point it's looking at down by "moveBy" on the x axis
        }
    }
    else if (mod == GLUT_ACTIVE_CTRL) // Check if roll is pressed
    {
        if (key == GLUT_KEY_UP) // Checking the up arrow
        {
            pitch += 2; // Rotates the camera pitch by 2 degrees

        }
        else if (key == GLUT_KEY_DOWN) // Checking the down arrow
        {
            pitch -= 2; // Rotates the camera pitch by 2 degrees

        }

        if (key == GLUT_KEY_RIGHT) // Checking the right arrow
        {
            yaw -= 2; //Change the Yaw of the camera by 2 degrees
        }
        else if (key == GLUT_KEY_LEFT) // Checking the right arrow
        {
            yaw += 2; //Change the Yaw of the camera by -2 degrees
        }
    }
    glutPostRedisplay(); //ReDisplay the scene with updated values
}

// Initializes GLUT and enters the main loop.
int main(int argc, char** argv)
{
    // Initialize GLUT based on arguments
    glutInit(&argc, argv);
    // Set the display of the window to a double buffer setting and add RGB color system with DEPTH 
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    //Set the origin of the window to (80,80)
    glutInitWindowPosition(80, 80);
    //Set the window size of the output to 800 x 600
    glutInitWindowSize(800, 600);
    //Create a window with the title "Project 9"
    glutCreateWindow("Advanced Shaders 2");
    // Set up display for drawing scene by calling display() function
    glutDisplayFunc(display);
    // Call reshape() function to reshape the window's display to the user's preferences
    glutReshapeFunc(reshape);
    glutKeyboardFunc(processNormalKeys);          // Take input from the keyboard to affect the program based on processNormalKeys()
    glutSpecialFunc(special);         //Take input from the keyboard to affect the program based on the special()
    glutTimerFunc(100, timer, 0);   //Calls the TimerFunction
    init();         // Set up color scheme for the window scene as well as initialize the settings
    glutMainLoop();         // Loop program for any possible changes until user ends program
}
