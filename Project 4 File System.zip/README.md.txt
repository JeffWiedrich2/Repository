Use the "root" command first, otherwise it won't work. 

For some reason, near the end, it stopped working in codeblocks for me, but
when I couldn't figure out what I was doing wrong, I sent it to a friend, and
it ran fine for him, so I don't know what's going on with that. 

Sorry I don't have it working 100%, it was the best I could get it before it was due. 
Hopefully this doesn't score poorly to the level where it fails me the class. 