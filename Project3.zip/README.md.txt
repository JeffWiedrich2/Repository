In order for the code to work you must make sure that in your terminal inside Ubuntu
 you type “ sudo apt-get install libreadline-dev”  
and download that for the code to function.