package com.example.roulette;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView iv_ball;
    EditText et_red, et_black, et_odd, et_even, et_1_12, et_13_24, et_25_36,
            et_numberChoice, et_numberBet;
    Button b_spin;
    TextView tv_cash, tv_youWin;
    int cash = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_ball = findViewById(R.id.iv_ball);
        et_red = findViewById(R.id.et_red);
        et_black = findViewById(R.id.et_black);
        et_odd = findViewById(R.id.et_odd);
        et_even = findViewById(R.id.et_even);
        et_1_12 = findViewById(R.id.et_1_12);
        et_13_24 = findViewById(R.id.et_13_24);
        et_25_36 = findViewById(R.id.et_25_36);
        et_numberChoice = findViewById(R.id.et_numberChoice);
        et_numberBet = findViewById(R.id.et_numberBet);
        b_spin = findViewById(R.id.b_spin);
        tv_cash = findViewById(R.id.tv_cash);
        tv_youWin = findViewById(R.id.tv_youWin);

        b_spin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int theSpinDegrees, numberSpacesSpun, selectedNumber, numberSpun, payout = 0;
                boolean red, oneTwelve, thirteenTwentyFour, twentyFiveThirtySix, black;

                Random r = new Random();

                theSpinDegrees = r.nextInt(360) + 720;

                RotateAnimation rotateBottle = new RotateAnimation(0, theSpinDegrees,
                        Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f);

                rotateBottle.setDuration(2000);
                rotateBottle.setFillAfter(true);

                rotateBottle.setInterpolator(new DecelerateInterpolator());

                iv_ball.startAnimation(rotateBottle);

                numberSpacesSpun = (int) (theSpinDegrees / 9.7297);

                //If statements to get values
                switch (numberSpacesSpun){
                    default:
                        red = false;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 0;
                        break;
                    case 0:
                        red = false;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 0;
                        break;
                    case 1:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 32;
                        break;
                    case 2:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 15;
                        break;
                    case 3:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 19;
                        break;
                    case 4:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 4;
                        break;
                    case 5:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 21;
                        break;
                    case 6:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 2;
                        break;
                    case 7:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 25;
                        break;
                    case 8:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 17;
                        break;
                    case 9:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 34;
                        break;
                    case 10:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 6;
                        break;
                    case 11:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 27;
                        break;
                    case 12:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 13;
                        break;
                    case 13:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 36;
                        break;
                    case 14:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 11;
                        break;
                    case 15:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 30;
                        break;
                    case 16:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 8;
                        break;
                    case 17:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 23;
                        break;
                    case 18:
                        red = false;
                        black = true;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 10;
                        break;
                    case 19:
                        red = true;
                        black = false;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 5;
                        break;
                    case 20:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 24;
                        break;
                    case 21:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 16;
                        break;
                    case 22:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 33;
                        break;
                    case 23:
                        red = true;
                        black = false;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 1;
                        break;
                    case 24:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 20;
                        break;
                    case 25:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 14;
                        break;
                    case 26:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 31;
                        break;
                    case 27:
                        red = true;
                        black = false;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 9;
                        break;
                    case 28:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 22;
                        break;
                    case 29:
                        red = true;
                        black = false;
                        oneTwelve = false;
                        thirteenTwentyFour = true;
                        twentyFiveThirtySix = false;
                        numberSpun = 18;
                        break;
                    case 30:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 29;
                        break;
                    case 31:
                        red = true;
                        black = false;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 7;
                        break;
                    case 32:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 35;
                        break;
                    case 33:
                        red = true;
                        black = false;
                        oneTwelve = true;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = false;
                        numberSpun = 3;
                        break;
                    case 34:
                        red = false;
                        black = true;
                        oneTwelve = false;
                        thirteenTwentyFour = false;
                        twentyFiveThirtySix = true;
                        numberSpun = 26;
                        break;
                }

                if (!et_red.getText().toString().equals("")){
                    if (red){
                        // Win
                        payout += Integer.parseInt(et_red.getText().toString());
                    }
                    else {
                        payout -= Integer.parseInt(et_red.getText().toString());
                    }
                }

                if (!et_black.getText().toString().equals("")){
                    if (black){
                        // Win
                        payout += Integer.parseInt(et_black.getText().toString());
                    }
                    else {
                        payout -= Integer.parseInt(et_black.getText().toString());
                    }
                }

                if (!et_1_12.getText().toString().equals("")){
                    if (oneTwelve){
                        // Win
                        payout += Integer.parseInt(et_1_12.getText().toString()) * 2;
                    }
                    else {
                        payout -= Integer.parseInt(et_1_12.getText().toString());
                    }
                }

                if (!et_13_24.getText().toString().equals("")) {
                    if (thirteenTwentyFour) {
                        // Win
                        payout += Integer.parseInt(et_13_24.getText().toString()) * 2;
                    }
                    else {
                        payout -= Integer.parseInt(et_13_24.getText().toString());
                    }
                }

                if (!et_25_36.getText().toString().equals("")){
                    if (twentyFiveThirtySix){
                        // Win
                        payout += Integer.parseInt(et_25_36.getText().toString()) * 2;
                    }
                    else {
                        payout -= Integer.parseInt(et_25_36.getText().toString());
                    }
                }

                if (!et_odd.getText().toString().equals("")){
                    if (numberSpun % 2 == 1){
                        // Win
                        payout += Integer.parseInt(et_odd.getText().toString());
                    }
                    else {
                        payout -= Integer.parseInt(et_odd.getText().toString());
                    }
                }

                if (!et_even.getText().toString().equals("")){
                    if (numberSpun % 2 == 0){
                        // Win
                        payout += Integer.parseInt(et_even.getText().toString());
                    }
                    else {
                        payout -= Integer.parseInt(et_even.getText().toString());
                    }
                }


                if (!et_numberChoice.getText().toString().equals("")){
                    selectedNumber = Integer.parseInt(et_numberChoice.getText().toString());
                    if (numberSpun == selectedNumber){
                        // Win
                        payout += Integer.parseInt(et_numberBet.getText().toString()) * 35;
                    }
                    else {
                        payout -= Integer.parseInt(et_numberBet.getText().toString());
                    }
                }

                cash += payout;
                tv_cash.setText("Cash: $" + cash);
                tv_youWin.setText("You win $" + payout);
            }
        });
    }
}