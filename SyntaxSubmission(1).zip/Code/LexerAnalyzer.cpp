

#include <stdbool.h> 
#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <iostream>
#include <fstream>



using namespace std;



ifstream inFile;
int lineNumber = 1;
ofstream outputFile("OutputFile.txt");



// Returns 'true' if the character is a DELIMITER. 
bool isDelimiter(char ch)
{
    if (ch == ' ' || ch == '+' || ch == '-' || ch == '*' ||
        ch == '/' || ch == ',' || ch == ';' || ch == '>' ||
        ch == '<' || ch == '=' || ch == '(' || ch == ')' ||
        ch == '[' || ch == ']' || ch == '{' || ch == '}') 
        return (true);
    return (false);
}

// Returns 'true' if the character is an OPERATOR. 
bool isOperator(char ch)
{
    if (ch == '+' || ch == '*' || ch == '/' || ch == '>' || ch == '<' || ch == '=' || ch == '&' || ch == '=' || ch == '!')
    {
        return (true);
    }
    return (false);
}


//Returns true if the character is a unaryOperator
bool unaryOperator(char ch)
{
    if (ch == '-' || ch == '!')
    {
        return (true);
    }
    return (false);
}

bool bracket(char ch)
{
    if (ch == '[' || ch == ']' || ch == '(' || ch == ')')
        return (true);
    return false;
}

bool block(char ch)
{
    if (ch == '{' || ch == '}')
        return(true);
    return false;
}

bool checkNotID(char ch)
{
    if (block(ch) == true || bracket(ch) == true || unaryOperator(ch) == true || isOperator(ch) == true)
        return (true);
    return (false);
}

bool isBinaryOperator(char* str)
{
    if (strcmp(str, "+") || strcmp(str, "-") || strcmp(str, "*") || strcmp(str, "/")
        || strcmp(str, "==") || strcmp(str, "!=") || strcmp(str, "<")
        || strcmp(str, "<=") || strcmp(str, ">") || strcmp(str, ">=")
        || strcmp(str, "&&") || strcmp(str, "||"))
    {
        return true;
    }
    return false;
}

// Returns 'true' if the string is a VALID IDENTIFIER by checking whether the first character starts with integer or not.
bool validIdentifier(char* str)
{
    if (str[0] == '0' || str[0] == '1' || str[0] == '2' ||
        str[0] == '3' || str[0] == '4' || str[0] == '5' ||
        str[0] == '6' || str[0] == '7' || str[0] == '8' ||
        str[0] == '9' || isDelimiter(str[0]) == true)
        return (false);
    return (true);
}

// Returns 'true' if the string is a KEYWORD. 
bool isKeyword(char* str)
{
    if (!strcmp(str, "if") || !strcmp(str, "else") ||
        !strcmp(str, "while") || !strcmp(str, "break") || !strcmp(str, "read") ||
        !strcmp(str, "write") || !strcmp(str, "writeln"))
        return (true);
    return (false);
}

bool Type(char* str)
{
    if (!strcmp(str, "int") || !strcmp(str, "char"))
        return (true);
    return false;
}

// Returns 'true' if the substring is intergers only
bool isInteger(char* str)
{
    int i, len = strlen(str);

    if (len == 0)
        return (false);
    for (i = 0; i < len; i++) {
        if (str[i] != '0' && str[i] != '1' && str[i] != '2'
            && str[i] != '3' && str[i] != '4' && str[i] != '5'
            && str[i] != '6' && str[i] != '7' && str[i] != '8'
            && str[i] != '9' || (str[i] == '-' && i > 0))
            return (false);
    }
    return (true);
}


// Extracts the SUBSTRING. 
char* subString(char* str, int left, int right)
{
    int i;
    char* subStr = (char*)malloc(
        sizeof(char) * (right - left + 2));

    for (i = left; i <= right; i++)
        subStr[i - left] = str[i];
    subStr[right - left + 1] = '\0';
    return (subStr);
}

// Parsing the input substring. 
void parse(char* str)
{

    //Having left and right values make it easier for us to traverse the char array to make sure 
    //where the word ends or the where the line ends and the new line begins

    int left = 0, right = 0;
    int len = strlen(str);

    while (right <= len && left <= right) {


        //using the imaginary right side to know when the line ends by comparing it to '\n' and incrementing the global linenumber variable.
        if (str[right] == '\n')
        {
            right++;
            left++;
            lineNumber++;
        }



        //Makes it so that if there are bunch of empty spaces or nothing before a char appears it increments the right value.
        if (isDelimiter(str[right]) == false)
            right++;


        //In this if statement we check each function by passing in the right index or the substring to know what the character 
        //or the substring is and storing it in the outputfile
        if (isDelimiter(str[right]) == true && left == right) {
            if (isOperator(str[right]) == true)
            {
                outputFile << str[right] << " | operator | " << lineNumber << endl;
                right++;
                if (isOperator(str[right]) == true)
                {
                    outputFile << str[left] << str[right] << " | operator | " << lineNumber << endl;
                }
            }
            if (unaryOperator(str[right]) == true)
            {
                outputFile << str[right] << " | operator | " << lineNumber << endl;
            }

            if (block(str[right]) == true)
            {
                outputFile << str[right] << " | block | " << lineNumber << endl;
            }

            if (str[right] == ';')
            {
                outputFile << str[right] << " | break | " << lineNumber << endl;
            }
            if (bracket(str[right]) == true)
            {
                outputFile << str[right] << " | bracket | " << lineNumber << endl;
            }

            right++;
            left = right;
        }
        else if (isDelimiter(str[right]) == true && left != right
            || (right == len && left != right)) {
            char* subStr = subString(str, left, right - 1);

            if (isKeyword(subStr) == true)
            {
                outputFile << subStr << " | Keyword | " << lineNumber << endl;
            }
            else if (Type(subStr) == true)
            {
                outputFile << subStr << " | Type |" << lineNumber << endl;
            }

            else if (isInteger(subStr) == true)
                outputFile << subStr << " | NUM | " << lineNumber << endl;


            else if (validIdentifier(subStr) == true
                //               && isDelimiter(str[right - 1]) == false
                //               && isKeyword(subStr) == false
                )
                outputFile << subStr << " | ID | " << lineNumber << endl;

            else if (validIdentifier(subStr) == false
                && isDelimiter(str[right - 1]) == false)
                outputFile << subStr << " | not an ID | " << lineNumber << endl;
            left = right;

        }
    }
    return;
}


// DRIVER FUNCTION 
int main()
{

    int i = 0;
    //char array where the data from the file is stored.
    char str[10000];


    //Opening up the file by asking user for the name of the file.
    string filename;
    cout << "Enter the name of the file" << endl;
    cout << "Filename: ";
    cin >> filename;

    inFile.open(filename);

    if (inFile.fail())
    {
        cout << "Error Opening the File\n" << "1. Make sure the name is entered correctly.\n" << "2. Make sure the file exists in this solution." << endl;
    }




    while (!inFile.eof() && i < 10000)
    {
        inFile.get(str[i]);
        i++;
    }

    //Opening/creating new file called OutputFile to store the information gathered from parsing the input file.
    ofstream outputFile("OutputFile.txt");


    parse(str);


    return (0);
}
