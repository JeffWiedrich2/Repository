/* Tree Parser
 *
 * Grammar: as per spreadsheet
 * Developer: Deep Contractor
 * implemented rule for missing type, identifier and add expressions
 */

//#include <string.h> 
//#include <ctype.h>
//#include <stdio.h>
//#include <stdlib.h>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

// functions declaration
void enter(char);
void leave(char);
void spaces(int);
bool VarDeclList(std::string str);
bool FuncDecList(std::string str);
char validateSyntax(std::string str);
std::string nextexpr = "X";
std::string prevexpr = "X";

// Global variables
int level;               // used for tree indentation
bool funcstart = false;  // identifies function start sequence
bool funcend = false;    // identifies function end sequence
bool blockstart = false; // identifies statement / function block start sequence
bool blockend = false;   // identifies statement / function block end sequence
int openbracketcnt = 0;  // identifies number of open brackets
int closebracketcnt = 0; // identifies number of closed brackets
int openblockcnt = 0;    // identifies number of open blocks
int closeblockcnt = 0;   // identifies number of closed blocks

bool VarDeclList(std::string str)
{
	char retval = ' ';
	std::string strval;
	std::string printstr;

	// validate syntax value and returns type of expression
	retval = validateSyntax(str);

	// convert return expressions to user defined text
	switch (retval) {
	case 'R':
		strval = "ROperator";
		break;
	case 'A':
		strval = "AOperator";
		break;
	case 'L':
		strval = "LOperator";
		break;
	case 'B':
		strval = "Bracket";
		break;
	case 'K':
		strval = "+-Block";
		break;
	case 'S':
		strval = "Statement";
		break;
	case 'D':
		if (funcstart)
		{
			strval = "ParamDecl - Type";
		}
		else
		{
			strval = "VarDecl - Type";
		}
		break;
	case 'E':
		strval = "Integer";
	case 'I':
		strval = "Identifier";
		break;
	case 'X':
		strval = "Break";
		break;
	default:
		strval = "Invalid";
	}

	// logic to built tree indent
	level = (openblockcnt + openbracketcnt);
	while (level-- > 0)
		printstr = printstr+"| ";

	//
	//  rules to check invalid or missing tags
	//	Dont have time to finish this :(
	//

	//  rule to check missing type 
	if (strval == "Identifier" and prevexpr != "type" and prevexpr != "operator" and prevexpr != "X" and funcstart)
	{
		std::cout << printstr << "<<Invalid>> - Missing Type" << std::endl;
		prevexpr = "X";
	}

	//  rule to check missing identifier 
	if ((strval == "ROperator" || strval == "AOperator" || strval == "LOperator") and ((prevexpr != "id" and prevexpr != "int") and blockstart))
	{
		std::cout << printstr << "<<Invalid>> - Missing Identifier" << std::endl;
		prevexpr = "X";
	}

	std::cout << printstr << strval << " " << str << std::endl;

	//  rule to add expressions
	if (str == "(" and nextexpr == "operator" and openbracketcnt > 0)
	{
		std::cout << printstr << "<<Expr>>" << std::endl;
		nextexpr = "X";
	}

	if (retval != ' ')
	  {return (true);}
	else
	  {return (false);}
}

bool FuncDecList(std::string str)
{
	std::string printstr;
	char retval = ' ';
	level = (openblockcnt + openbracketcnt);
	while (level-- > 0)
		printstr = printstr + "| ";
	std::cout << "Function" << " " << str << std::endl;
	if (retval != ' ')
	{ return (true);}
	else
	{ return (false);}
}

char validateSyntax(std::string str)
{
	char retval = ' ';
	size_t i = 0;
    std::string searchstr = " ";
	searchstr = "," + str + ",";
	
	//I broke the operators into their uses

	// Relational Operators
	std::string roper = ",=, ,==, ,!=, ,<, ,<=, ,>, ,>=,";

	// Arithmetic Operators
	std::string aoper = ",+, ,-, ,*, ,/, ,++, ,--,";

	// Logical Operators
	std::string loper = ",&&, ,||, ,!,";

	// Brackets
	std::string boper = ",(, ,),";

	// Block
	std::string blkoper = ",{, ,}, ,[, ,],";

	// Data Type
	std::string datatype = ",int, ,char,";

	// Break
	std::string breaktype = ",;,";

	// Statements
	std::string stmttype = ",if, ,else, ,read, ,return, ,write, ,writeln, ,break, ,while,";

	std::string integer = ",1, ,2, ,3, ,4, ,5, ,6, ,7, ,8, ,9, ,0,";

   // search for relational operators
	i = roper.find(searchstr);
	if (i != std::string::npos) {retval = 'R';}

	// search for arithmetic operators
	if (retval == ' ')
	{
		i = 0;
		i = aoper.find(searchstr);
		if (i != std::string::npos) { retval = 'A'; }
	}

	// search for logical operators
	if (retval == ' ')
	{
		i = 0;
		i = loper.find(searchstr);
		if (i != std::string::npos) { retval = 'L'; }
	}

	// search for brackets
	if (retval == ' ')
	{
		i = 0;
		i = boper.find(searchstr);
		if (i != std::string::npos) { retval = 'B'; }
	}

	if (retval == ' ')
	{
		i = 0;
		i = blkoper.find(searchstr);
		if (i != std::string::npos) { retval = 'K'; }
	}

	// search for data type
	if (retval == ' ')
	{
		i = 0;
		i = datatype.find(searchstr);
		if (i != std::string::npos) { retval = 'D'; }
	}

	// search for data type
	if (retval == ' ')
	{
		i = 0;
		i = stmttype.find(searchstr);
		if (i != std::string::npos) { retval = 'S'; }
	}

	// search for break char
	if (retval == ' ')
	{
		i = 0;
		i = breaktype.find(searchstr);
		if (i != std::string::npos) { retval = 'X'; }
	}

	if (retval == ' ')
	{
		i = 0;
		i = integer.find(searchstr);
		if (i != std::string::npos) { retval = 'E'; }
	}

	// all other are considered as Identifiers
	if (retval == ' ')
		retval = 'I';

	return retval;
}

// Function to split string based on the delimiter
std::vector<std::string> split(std::string s, std::string delimiter) {
	size_t pos_start = 0, pos_end, delim_len = delimiter.length();
	std::string token;
	std::vector<std::string> res;

	while ((pos_end = s.find(delimiter, pos_start)) != std::string::npos) {
		token = s.substr(pos_start, pos_end - pos_start);
		pos_start = pos_end + delim_len;
		res.push_back(token);
	}

	res.push_back(s.substr(pos_start));
	return res;
}

int main(void)
{
	// Open the source file.
	std::fstream newfile;
	newfile.open("outputA.txt", std::ios::in); //Change the file name here to match your output.

	std::string astr[27][3]; // array to load source file
	std::string nextval; // next value in the array
	std::string currval; // current value in the array
	int colnum = 0; // column number of the array
	int rownum = 0; // row number of the array
	int checkrow = 0; // to identify next value in the array

	if (newfile.is_open())
	{
		rownum = 0;
		std::string str;
		// read file
		while (getline(newfile, str))
		{

			// parse columns
			std::string delimiter = " | ";
			std::vector<std::string> v = split(str, delimiter);

			// populate astr array
			for (auto i : v)
			{
				astr[rownum][colnum] = i;
				colnum++;
			}
			rownum++;
			colnum = 0;
		}
	}

	// Get rowcount of array
	rownum = sizeof(astr) / sizeof(astr[0]);

	// start reading the array
	for (int i = 0; i < rownum; i++)
	{
		checkrow = i + 1;
		if (checkrow < rownum)
		{
			nextval = astr[checkrow][0];
		}

		if (checkrow + 1 < rownum)
		{
			nextexpr = astr[checkrow+1][1];
		}

		currval = astr[i][0];

		// if firt value is not of Type stop the process
		if (i == 0 and astr[i][1] != "type")
			{
			std::cout << "Invalid File" << std::endl;
			break;
			}
		std::string switchval = astr[i][1];

		// process the data of only identified token values
		if (switchval == "type" || switchval == "bracket" || switchval == "break" || switchval == "id" || switchval == "block" || switchval == "operator" || switchval == "statement" || switchval == "int" || switchval == "char")
		{
			// logic to identify function
			if (nextval == "(")
			{
				openbracketcnt++;
				if (astr[i][1] != "statement")
				{
					funcstart = true;
					funcend = false;
					enter('F');
				}
			}

			// logic to identify blocks
			if (currval == "{")
			{
				blockstart = true;
				blockend = false;
				openblockcnt++;
				openblockcnt++;
			}

			if (i - 1 >= 0)
			{
				prevexpr = astr[i - 1][1];
			}

			if (funcstart == true and nextval=="(")
			{
			
				// Scenario A -> E - check FuncDecList
				FuncDecList(currval);
			}
			else
			{
				
				VarDeclList(currval);
			}

			// logic to close function
			if (currval == ")")
			{
				funcstart = false;
				funcend = false;
				openbracketcnt--;
			}

			// logic to close blocks
			if (currval == "}")
			{
				blockstart = false;
				blockend = false;
				openblockcnt--;
				openblockcnt--;
				if (openblockcnt == 0)
					leave('F');
			}
		}
	}

	return 0;
}

// Create the tree node
void enter(char name)
{
	spaces(level++);
	printf("+-%c: ", name);
}

// End the tree node
void leave(char name)
{
	spaces(--level);
	printf("+-%c: ", name);
}

void spaces(int local_level)
{
	while (local_level-- > 0)
		printf("| ");
}