----------------Instruction to Run the Syntax Analyzer--------------

Things given:
LexerAnalyzer.cpp file
Syntax.Analyzer.cpp file 
Test file for Syntax Analyzer - outPutA.txt



-> So first drag your original input file in the project.
-> Run the Lexer Analyzer (it will ask for your file)
   Input your file name correctly.
-> It will generate an OutPut.txt
-> Open up the OutPut.txt file and please clean up the file
   by deleting the garbage values. 
-> Go to the Syntax Analyzer cpp file and go the line 270
   and change the outputA.txt to the file we generated.
--> It should be OutPut.txt
--> Run the program and it should generate the parse tree.